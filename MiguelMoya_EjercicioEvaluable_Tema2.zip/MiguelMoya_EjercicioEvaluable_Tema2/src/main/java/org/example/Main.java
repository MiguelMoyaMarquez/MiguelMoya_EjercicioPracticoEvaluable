package org.example;


import org.example.dao.JdbcUtils;
import org.example.dao.PeliculaDAO;
import org.example.model.Pelicula;

import java.sql.Connection;

public class Main {
    public static void main(String[] args) {
        Connection connection = JdbcUtils.getConn();

        PeliculaDAO peliculaDAO = new PeliculaDAO(connection);

        Pelicula nuevaPelicula=new Pelicula();
        nuevaPelicula.setTitulo("Tiburones");
        nuevaPelicula.setAge(1992);
        nuevaPelicula.setGenero("Accion");
        System.out.println(nuevaPelicula);
        peliculaDAO.save(nuevaPelicula);
        System.out.println(nuevaPelicula);
    }
}