package org.example.dao;

import org.example.model.Pelicula;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PeliculaDAO implements DAO<Pelicula> {
    Connection con;

    public PeliculaDAO(Connection c){
        con=c;
    }


    @Override
    public List<Pelicula> findAll() {
        List<Pelicula> listaPelicula = new ArrayList<>();

        try (PreparedStatement ps = con.prepareStatement("SELECT * FROM peliculas")) {
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Pelicula pelicula = new Pelicula();
                pelicula.setId(rs.getInt("id"));
                pelicula.setTitulo(rs.getString("titulo"));
                pelicula.setAge(rs.getInt("año"));
                pelicula.setGenero(rs.getString("edad"));

                listaPelicula.add(pelicula);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listaPelicula;
    }

    @Override
    public Pelicula findById(Integer id) {
        return null;
    }

    @Override
    public void save(Pelicula pelicula) {
        if (pelicula == null) {
            throw new IllegalArgumentException("La pelicula no puede ser null");
        }

        String query = "INSERT INTO peliculas(titulo, año, genero) VALUES (?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, pelicula.getTitulo());
            ps.setString(2, pelicula.getGenero());
            ps.setInt(3, pelicula.getAge());

            ps.executeUpdate();


            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    pelicula.setId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("No se pudo obtener el ID generado.");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Pelicula pelicula) {

    }

    @Override
    public void delete(Pelicula pelicula) {

    }

    public Pelicula findByAge(int ageMin, int ageMax){

        Pelicula pelicula = null;
        String sql = "SELECT * FROM peliculas WHERE año >= ageMin and año <= ageMax";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                pelicula = new Pelicula();
                pelicula.setId(rs.getInt("id"));
                pelicula.setTitulo(rs.getString("titulo"));
                pelicula.setAge(rs.getInt("año"));
                pelicula.setGenero(rs.getString("genero"));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar pelicula", e);
        }

        return pelicula;
    }

}
